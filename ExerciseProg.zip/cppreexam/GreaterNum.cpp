#include<iostream>
using namespace std;
int main(){
int n1,n2;
cout<<"enter the numbers";
cin>>n1>>n2;
if(n1>n2){
	cout<<n1<<" "<<"is greater"<<endl;
}
else{
		cout<<n2<<" "<<"is greater"<<endl;
}
	return 0;
}
